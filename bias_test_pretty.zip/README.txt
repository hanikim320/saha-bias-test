# 깔끔 링크 만들기 (GitHub Pages · 60초 버전)

1) GitHub에서 새 저장소 생성 (예: `bias-test`)
2) `index.html` 파일 1개만 업로드
3) 저장소 **Settings → Pages** → `Deploy from a branch` 선택
4) Branch: `main` · Folder: `/root` → **Save**
5) 잠시 후 상단에 배포 주소 표시: `https://<본인아이디>.github.io/bias-test`

> 이 URL이 바로 학생에게 배포할 **예쁜 링크**입니다. 크롬에서 URL 공유 → **QR 코드 만들기**로 PNG 저장 가능.

### 참고
- 학교망에서 외부 CDN 차단 시 차트만 숨기고 나머지는 정상 동작합니다.
- 결과 인쇄는 **전 문항 응답 후** 버튼이 활성화됩니다.
